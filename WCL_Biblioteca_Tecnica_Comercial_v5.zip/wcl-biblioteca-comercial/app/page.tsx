'use client';
import {useMemo,useState} from 'react';
import Link from 'next/link';

const categories=['Carros','Utilitários (ônibus, vans e caminhões)','Motos','Máquinas agrícolas e empilhadores'];
const examples=[
 {category:categories[0],make:'Fiat',model:'Pulse',years:'2022–2025',count:3},
 {category:categories[0],make:'Volkswagen',model:'Polo',years:'2018–2025',count:5},
 {category:categories[0],make:'Chevrolet',model:'Onix',years:'2020–2025',count:4},
 {category:categories[1],make:'Mercedes-Benz',model:'Sprinter',years:'2019–2025',count:2},
 {category:categories[1],make:'Volvo',model:'FH',years:'2020–2025',count:3},
 {category:categories[1],make:'Scania',model:'R-Series',years:'2018–2025',count:2},
 {category:categories[2],make:'Honda',model:'CG 160',years:'2020–2025',count:2},
 {category:categories[2],make:'Yamaha',model:'Fazer 250',years:'2019–2024',count:1},
 {category:categories[3],make:'John Deere',model:'Trator 6M',years:'2021–2025',count:1},
 {category:categories[3],make:'Toyota',model:'Empilhadeira 8FG',years:'2019–2024',count:1}
];
const moduleExamples=[
 {category:categories[0],make:'Fiat',model:'Pulse',years:'2022–2025',count:2},
 {category:categories[0],make:'Volkswagen',model:'T-Cross',years:'2020–2025',count:1},
 {category:categories[1],make:'Mercedes-Benz',model:'Sprinter',years:'2019–2025',count:1},
 {category:categories[2],make:'Honda',model:'CG 160',years:'2021–2025',count:1}
];
export default function Home(){
 const [section,setSection]=useState<'rastreador'|'cofre'>('rastreador');
 const [category,setCategory]=useState('Todas');
 const [query,setQuery]=useState('');
 const [locked,setLocked]=useState<{make:string;model:string;kind:string}|null>(null);
 const items=section==='rastreador'?examples:moduleExamples;
 const filtered=useMemo(()=>items.filter(x=>(category==='Todas'||x.category===category)&&(`${x.make} ${x.model} ${x.years}`).toLowerCase().includes(query.toLowerCase())),[items,category,query]);
 return <><header className="nav"><div className="brand">WCL <small>BIBLIOTECA TÉCNICA</small></div><div className="row"><Link className="btn secondary" href="/login">Entrar</Link><Link className="btn" href="/assinar">Assinar</Link></div></header>
 <main className="wrap">
  <section className="hero"><span className="tag">BIBLIOTECA TÉCNICA AUTOMOTIVA</span><h1>Conhecimento técnico para cada veículo.</h1><p>Consulte nosso catálogo de veículos e conheça os padrões disponíveis. Assinantes têm acesso aos diagramas, fotos e procedimentos completos.</p><div className="row"><Link className="btn" href="/assinar">Planos a partir de R$ 19,90</Link><Link className="btn secondary" href="/login">Já sou assinante</Link></div></section>
  <section className="card" style={{marginBottom:18}}><div className="row" style={{justifyContent:'space-between'}}><div><h2 style={{marginBottom:5}}>Explore a WCL</h2><p className="muted" style={{marginTop:0}}>O catálogo de modelos é visível para todos. O conteúdo técnico é exclusivo para assinantes.</p></div></div>
   <div className="row"><button className={section==='rastreador'?'btn':'btn secondary'} onClick={()=>{setSection('rastreador');setCategory('Todas');setQuery('');}}>Padrões de rastreadores</button><button className={section==='cofre'?'btn':'btn secondary'} onClick={()=>{setSection('cofre');setCategory('Todas');setQuery('');}}>Cofre de módulos</button></div>
  </section>
  <section className="card">
   <div className="row" style={{justifyContent:'space-between'}}><div><h2 style={{margin:'0 0 5px'}}>{section==='rastreador'?'Padrões de instalação de rastreadores':'Cofre de módulos'}</h2><p className="muted" style={{margin:0}}>{section==='rastreador'?'Encontre os veículos com padrões cadastrados.':'Biblioteca separada de aplicações e procedimentos de cofres de módulos.'}</p></div><span className="tag">{filtered.length} exemplos</span></div>
   <input className="field" style={{marginTop:18}} placeholder="Pesquisar fabricante ou modelo..." value={query} onChange={e=>setQuery(e.target.value)}/>
   <div className="row" style={{marginBottom:16}}><button className={category==='Todas'?'btn':'btn secondary'} onClick={()=>setCategory('Todas')}>Todas</button>{categories.map(c=><button key={c} className={category===c?'btn':'btn secondary'} onClick={()=>setCategory(c)}>{c}</button>)}</div>
   <div className="grid">{filtered.map((v,i)=><article className="card" key={v.make+v.model} style={{boxShadow:'none'}}>
    <div className="row" style={{justifyContent:'space-between'}}><span className="tag">{v.category}</span><span className="muted" style={{fontSize:12}}>{v.count} {section==='rastreador'?'padrões':'procedimentos'}</span></div>
    <h3 style={{marginBottom:4}}>{v.make} {v.model}</h3><p className="muted" style={{marginTop:0,fontSize:13}}>Anos: {v.years}</p>
    <button className="btn" style={{width:'100%'}} onClick={()=>setLocked({make:v.make,model:v.model,kind:section==='rastreador'?'padrão de rastreador':'cofre de módulo'})}>Ver {section==='rastreador'?'padrões':'procedimentos'} <span style={{marginLeft:8}}>🔒</span></button>
   </article>)}</div>
   {filtered.length===0&&<p className="muted">Nenhum modelo encontrado nesta pesquisa.</p>}
  </section>
  <section className="grid" style={{marginTop:18}}><article className="card"><h3>Catálogo aberto</h3><p className="muted">Qualquer visitante pode conferir categorias, fabricantes, modelos e anos disponíveis.</p></article><article className="card"><h3>Conteúdo exclusivo</h3><p className="muted">Fotos, diagramas e procedimentos completos ficam protegidos para assinantes ativos.</p></article><article className="card"><h3>Envios revisados</h3><p className="muted">Novos conteúdos só entram na galeria depois da aprovação da WCL.</p></article></section>
  <section className="card" style={{marginTop:18}}><h2>Escolha seu plano</h2><p className="muted">Todos os planos incluem acesso às duas bibliotecas: padrões de rastreadores e cofre de módulos.</p><div className="grid"><article className="card" style={{boxShadow:'none'}}><h3>Mensal</h3><div className="price">R$ 19,90</div><p className="muted">Por mês</p></article><article className="card" style={{boxShadow:'none'}}><h3>Semestral</h3><div className="price">R$ 99,99</div><p className="muted">Por 6 meses · pagamento antecipado</p></article><article className="card" style={{boxShadow:'none'}}><h3>Anual</h3><div className="price">R$ 199,99</div><p className="muted">Por 12 meses · pagamento antecipado</p></article></div><p className="muted">Teste grátis de 7 dias, sujeito às condições e à disponibilidade apresentadas no checkout.</p><Link className="btn" href="/assinar">Assinar e liberar a biblioteca</Link></section>
  <p className="footer">WCL Biblioteca Técnica · Consulte sempre a documentação do fabricante e confirme a aplicação exata por ano e versão.</p>
 </main>
 {locked&&<div role="presentation" onClick={()=>setLocked(null)} style={{position:'fixed',inset:0,background:'#071827b8',display:'grid',placeItems:'center',padding:18,zIndex:20}}><div role="dialog" aria-modal="true" aria-labelledby="paywall-title" onClick={e=>e.stopPropagation()} className="card" style={{maxWidth:440,width:'100%',padding:26}}>
  <div className="row" style={{justifyContent:'space-between'}}><span className="tag warn">Conteúdo exclusivo</span><button className="btn secondary" onClick={()=>setLocked(null)}>Fechar</button></div>
  <h2 id="paywall-title">Desbloqueie este conteúdo</h2><p className="muted">Você selecionou <b>{locked.make} {locked.model}</b> na área de {locked.kind}. O catálogo é público, mas fotos, diagramas e procedimentos completos são exclusivos para assinantes.</p>
  <div className="price">A partir de R$ 19,90</div><p className="muted">Planos mensal, semestral e anual. Consulte os valores na página de assinatura.</p><Link className="btn" style={{width:'100%'}} href="/assinar">Assinar agora</Link><button className="btn secondary" style={{width:'100%',marginTop:8}} onClick={()=>setLocked(null)}>Continuar explorando modelos</button>
 </div></div>}
 </>;
}
