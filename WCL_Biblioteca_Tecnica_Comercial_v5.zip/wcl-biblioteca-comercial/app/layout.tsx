import './globals.css';
import type { Metadata } from 'next';
export const metadata: Metadata = {title:'WCL Biblioteca Técnica',description:'Biblioteca técnica automotiva por assinatura'};
export default function RootLayout({children}:{children:React.ReactNode}) { return <html lang="pt-BR"><body>{children}</body></html>; }
