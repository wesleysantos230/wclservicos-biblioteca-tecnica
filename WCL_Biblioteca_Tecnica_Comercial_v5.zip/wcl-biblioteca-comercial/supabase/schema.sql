-- WCL Biblioteca Técnica: esquema inicial. Execute no SQL Editor do Supabase.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  role text not null default 'subscriber' check (role in ('admin','reviewer','subscriber')),
  created_at timestamptz not null default now()
);

create table if not exists public.subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  provider text not null default 'mercadopago',
  provider_subscription_id text unique,
  status text not null default 'pending' check (status in ('trialing','authorized','pending','paused','cancelled','past_due','expired')),
  plan_amount numeric(10,2) not null default 19.90,
  currency text not null default 'BRL',
  trial_ends_at timestamptz,
  current_period_end timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.vehicle_categories (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  created_at timestamptz not null default now()
);

create table if not exists public.vehicle_manufacturers (
  id uuid primary key default gen_random_uuid(),
  category_id uuid not null references public.vehicle_categories(id),
  name text not null,
  unique(category_id, name)
);

create table if not exists public.vehicles (
  id uuid primary key default gen_random_uuid(),
  category_id uuid references public.vehicle_categories(id),
  manufacturer_id uuid references public.vehicle_manufacturers(id),
  make text not null, model text not null, year_start int, year_end int,
  engine_version text, fuel text, created_at timestamptz not null default now()
);

create table if not exists public.pattern_submissions (
  id uuid primary key default gen_random_uuid(),
  submitted_by uuid not null references auth.users(id),
  vehicle_id uuid references public.vehicles(id),
  make text not null, model text not null, year int, engine_version text,
  tracker_type text, procedure text,
  vehicle_photo_url text,
  installation_area_photo_url text,
  installation_area_description text,
  wire_records jsonb not null default '[]'::jsonb,
  optional_video_url text,
  photo_urls text[] default '{}',
  diagram_urls text[] default '{}',
  diagram_vehicle_photo_url text,
  photo_taken_at date,
  photo_caption text,
  submitter_confirmed boolean not null default false,
  status text not null default 'pending' check (status in ('pending','approved','changes_requested','rejected')),
  reviewed_by uuid references auth.users(id), reviewed_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.patterns (
  id uuid primary key default gen_random_uuid(),
  vehicle_id uuid references public.vehicles(id),
  make text not null, model text not null, year int, engine_version text,
  tracker_type text, procedure text,
  vehicle_photo_url text,
  installation_area_photo_url text,
  installation_area_description text,
  wire_records jsonb not null default '[]'::jsonb,
  optional_video_url text,
  photo_urls text[] default '{}',
  diagram_urls text[] default '{}',
  diagram_vehicle_photo_url text,
  photo_taken_at date,
  photo_caption text,
  reviewed_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.subscriptions enable row level security;
alter table public.vehicle_categories enable row level security;
alter table public.vehicle_manufacturers enable row level security;
alter table public.vehicles enable row level security;
alter table public.pattern_submissions enable row level security;
alter table public.patterns enable row level security;

-- Perfil: cada usuário lê o próprio. Admins devem ser provisionados manualmente pelo proprietário.
create policy "read own profile" on public.profiles for select to authenticated using (id = auth.uid());
create policy "read own subscription" on public.subscriptions for select to authenticated using (user_id = auth.uid());
create policy "read categories authenticated" on public.vehicle_categories for select to authenticated using (true);
create policy "read manufacturers authenticated" on public.vehicle_manufacturers for select to authenticated using (true);
create policy "read vehicles authenticated" on public.vehicles for select to authenticated using (true);
create policy "submit own patterns" on public.pattern_submissions for insert to authenticated with check (submitted_by = auth.uid());
create policy "read own submissions" on public.pattern_submissions for select to authenticated using (submitted_by = auth.uid());
create policy "read patterns for authenticated" on public.patterns for select to authenticated using (exists (
  select 1 from public.subscriptions s where s.user_id = auth.uid()
  and s.status in ('trialing','authorized')
  and (s.trial_ends_at is null or s.trial_ends_at > now())
  and (s.current_period_end is null or s.current_period_end > now())
));

-- IMPORTANTE:
-- 1) Esta é uma base inicial, não uma configuração de produção completa.
-- 2) Não exponha a service_role key no navegador.
-- 3) Webhook do Mercado Pago precisa validar assinatura e atualizar subscriptions no servidor.
-- 4) Acrescente policies administrativas com role confiável em app_metadata/claims ou função SQL segura.
-- 5) Para produção, testar permissões de leitura, gravação e bloqueio de assinaturas expiradas.



-- Categorias simplificadas da WCL
insert into public.vehicle_categories(name) values
('Carros'),
('Utilitários (ônibus, vans e caminhões)'),
('Motos'),
('Máquinas agrícolas e empilhadores')
on conflict (name) do nothing;

-- Catálogo público: somente metadados não sensíveis. Nunca inclua fotos,
-- diagramas, fios, locais técnicos ou procedimentos nesta tabela.
create table if not exists public.public_catalog (
  id uuid primary key default gen_random_uuid(),
  section text not null check (section in ('tracker','module_vault')),
  category text not null,
  manufacturer text not null,
  model text not null,
  year_label text,
  available_items_count integer not null default 1,
  created_at timestamptz not null default now()
);
alter table public.public_catalog enable row level security;
create policy "public can browse safe catalog" on public.public_catalog
for select to anon, authenticated using (true);

-- Área independente: Cofre de Módulos
create table if not exists public.module_vault_submissions (
  id uuid primary key default gen_random_uuid(),
  submitted_by uuid not null references auth.users(id),
  category text not null,
  manufacturer text not null,
  model text not null,
  year int,
  vehicle_photo_url text,
  module_photo_url text,
  procedure text,
  reference_diagram_urls text[] default '{}',
  optional_video_url text,
  status text not null default 'pending'
    check (status in ('pending','approved','changes_requested','rejected')),
  reviewed_by uuid references auth.users(id),
  reviewed_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.module_vault_patterns (
  id uuid primary key default gen_random_uuid(),
  category text not null,
  manufacturer text not null,
  model text not null,
  year int,
  vehicle_photo_url text,
  module_photo_url text,
  procedure text,
  reference_diagram_urls text[] default '{}',
  optional_video_url text,
  reviewed_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);

alter table public.module_vault_submissions enable row level security;
alter table public.module_vault_patterns enable row level security;

create policy "submit own module vault entry" on public.module_vault_submissions
for insert to authenticated with check (submitted_by = auth.uid());
create policy "read own module vault submissions" on public.module_vault_submissions
for select to authenticated using (submitted_by = auth.uid());

-- A leitura das instruções completas do cofre exige assinatura ativa.
create policy "active subscribers read module vault" on public.module_vault_patterns
for select to authenticated using (exists (
  select 1 from public.subscriptions s where s.user_id = auth.uid()
  and s.status in ('trialing','authorized')
  and (s.trial_ends_at is null or s.trial_ends_at > now())
  and (s.current_period_end is null or s.current_period_end > now())
));

-- Importante: manter os buckets de fotos, diagramas e vídeos privados.
-- O catálogo público recebe apenas fabricante/modelo/ano/categoria/quantidade.
-- O conteúdo completo deve ser servido por URLs assinadas após validar assinatura.
